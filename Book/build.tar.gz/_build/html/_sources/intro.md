# Introduction

In this project a code for the solution of the post-shock chemical relaxation problem is presented, validated and the results for some relevant cases are analyzed.

:::{note}
The code is written to be easily edited and re-used
:::
